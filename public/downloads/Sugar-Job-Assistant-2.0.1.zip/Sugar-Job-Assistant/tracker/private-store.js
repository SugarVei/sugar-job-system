(function (root) {
  'use strict';
  // Extension-origin IndexedDB is not exposed to recruitment-page content scripts.
  let connection;
  function database() { return connection ||= new Promise((resolve, reject) => { const r = indexedDB.open('sugar-job-tracker-private-v1', 1); r.onupgradeneeded = () => r.result.createObjectStore('private'); r.onsuccess = () => resolve(r.result); r.onerror = () => reject(r.error); }); }
  async function get(key) { const db = await database(); return new Promise((resolve,reject) => { const tx = db.transaction('private','readonly'); const r = tx.objectStore('private').get(key); r.onsuccess = () => resolve(r.result); r.onerror = () => reject(r.error); }); }
  async function set(key, value) { const db = await database(); return new Promise((resolve,reject) => { const tx = db.transaction('private','readwrite'); tx.objectStore('private').put(value,key); tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); }); }
  async function remove(key) { const db = await database(); return new Promise((resolve,reject) => { const tx = db.transaction('private','readwrite'); tx.objectStore('private').delete(key); tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); }); }
  root.SugarTrackerPrivate = Object.freeze({ get, set, remove });
})(globalThis);
