(function (root) {
  'use strict';
  root.SugarTrackerConfig = Object.freeze({
    version: '2.0.1', website: 'https://www.sugarv.mom',
    supabaseUrl: 'https://evnnkfclhxmjprttcmal.supabase.co',
    publishableKey: 'sb_publishable_yuADPzuWGCHm7vZFNcjucw_R3D9ciXu',
    websiteOrigins: ['https://www.sugarv.mom', 'https://sugarv.mom', 'https://sugar-job-system.vercel.app'],
    maxJobs: 120, maxPages: 8, maxQueue: 400,
  });
})(globalThis);
