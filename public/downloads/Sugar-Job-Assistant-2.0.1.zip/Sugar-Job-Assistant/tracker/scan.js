(function () {
  'use strict';
  if (window !== window.top) return;
  const version='2.0.1';
  if (globalThis.__sugarJobScanner?.version===version) { globalThis.__sugarJobScanner.refresh(); return; }
  globalThis.__sugarJobScanner?.dispose?.();
  const C=globalThis.SugarTrackerCore;
  let timer, lastFingerprint='', running=false, pending=false, lastRun=0, hint;
  const send = message => chrome.runtime.sendMessage({namespace:'sugar-tracker',...message});
  const jobPattern=/岗位|职位|招聘|校招|校园|社会招聘|campus|careers?|recruit|vacanc|positions?|jobs?|应聘/i;
  const titlePattern=/工程师|专员|经理|顾问|助理|实习|开发|研发|设计|运营|销售|分析|技术员|计划员|研究员|管培|engineer|developer|analyst|manager|intern|designer|specialist/i;
  const ignored=/^(?:查看详情|详情|了解更多|投递|立即申请|申请|职位列表|全部职位|更多职位|搜索|登录|注册|职位搜索|岗位搜索|careers|jobs|apply|learn more|details)$/i;
  function visibleText(el,max=18000) { if(!el)return ''; const copy=el.cloneNode(true);copy.querySelectorAll('script,style,noscript,form,input,textarea,select,[contenteditable],nav,footer,[data-sugar-tracker]').forEach(n=>n.remove());return C.redact(C.text(copy.textContent,max)); }
  function metadata(name) { return document.querySelector(`meta[property="${name}"],meta[name="${name}"]`)?.content||''; }
  function companyEvidence() {
    const evidence=[],seen=new Set();
    const add=(kind,value)=>{const text=C.redact(C.text(value,500));if(!text||seen.has(kind+'|'+text)||evidence.length>=45)return;seen.add(kind+'|'+text);evidence.push({kind,text});};
    add('site_name',metadata('og:site_name'));add('page_title',document.title);add('description',metadata('description'));
    const walk=(v,depth=0)=>{if(!v||depth>8)return;if(Array.isArray(v)){v.slice(0,150).forEach(x=>walk(x,depth+1));return;}if(typeof v!=='object')return;if([v['@type']].flat().some(t=>['Organization','Corporation'].includes(t)))add('organization',v.name);for(const key of ['@graph','publisher','hiringOrganization','mainEntity','itemListElement','item'])walk(v[key],depth+1);};
    for(const node of document.querySelectorAll('script[type="application/ld+json"]')){try{walk(JSON.parse(node.textContent));}catch{}}
    for(const el of [...document.querySelectorAll('[data-company-name],[class*="company-name"],[class*="companyName"]')].slice(0,20))add('company_label',el.getAttribute('data-company-name')||visibleText(el,180));
    for(const el of [...document.querySelectorAll('header,[role="banner"],[class*="header"],[id*="header"],[class*="logo"],[id*="logo"]')].slice(0,20)){
      if(el.closest('form,[data-sugar-tracker]'))continue;
      if(/logo/i.test(String(el.className)+' '+el.id)){add('logo',el.getAttribute('aria-label'));add('logo',el.getAttribute('title'));add('logo',visibleText(el,100));}
      else add('header',visibleText(el,700));
    }
    for(const el of [...document.querySelectorAll('img,svg')].slice(0,120)){
      if(el.closest('form,[data-sugar-tracker]'))continue;
      const branded=el.closest('header,[role="banner"],[class*="header"],[class*="logo"],[id*="logo"]')||/logo/i.test(String(el.className)+' '+el.id+' '+el.getAttribute('src'));
      if(!branded)continue;
      add('logo',el.getAttribute('alt'));add('logo',el.getAttribute('aria-label'));add('logo',el.getAttribute('title'));
      if(el.tagName.toLowerCase()==='svg')add('logo',el.querySelector('title')?.textContent);
    }
    for(const el of [...document.querySelectorAll('footer,[class*="copyright"],[id*="copyright"]')].slice(0,4))add('copyright',visibleText(el,600));
    return evidence;
  }
  function build(manual) {
    const structured=[];
    for(const node of document.querySelectorAll('script[type="application/ld+json"]')){try{for(const j of C.jsonJobs(JSON.parse(node.textContent))) {const parsed=C.fromJSONLD(j,location.href);if(parsed)structured.push(parsed);}}catch{}}
    const headings=[...document.querySelectorAll('h1,h2,h3,[class*="job-title"],[class*="position-title"]')].slice(0,70).map(el=>visibleText(el,160)).filter(Boolean);
    const likely=structured.length || jobPattern.test(location.pathname+' '+document.title+' '+headings.join(' '));
    if(!likely && !manual)return null;
    const company_evidence=companyEvidence();
    const distinctCompanies=new Set([...structured.map(j=>C.normalize(j.company)),...company_evidence.filter(x=>x.kind==='company_label').map(x=>C.normalize(x.text))].filter(Boolean));
    const company_scope=distinctCompanies.size>1?'multiple':'single';
    const company=C.inferCompany({url:location.href,title:document.title,structured,company_evidence,company_scope});
    const links=[],seen=new Set();
    for(const a of document.querySelectorAll('a[href]')){
      const url=C.safeUrl(a.getAttribute('href'),location.href);if(!url)continue;
      let label=visibleText(a,160),card=a.closest('[class*="job"],[class*="position"],[class*="recruit"],article,li,[role="listitem"]');
      if(!card||card===a)card=a.parentElement;
      const cardHeading=card?.querySelector('h1,h2,h3,h4,[class*="title"],[class*="name"]');
      if(!label||ignored.test(label))label=visibleText(cardHeading,160);
      if(!label||ignored.test(label)||label.length>120)continue;
      if(!titlePattern.test(label) && !jobPattern.test(new URL(url).pathname))continue;
      const key=url+'|'+label;if(seen.has(key))continue;seen.add(key);
      links.push({id:'a'+links.length,url,text:label,context:visibleText(card,1400)});if(links.length>=160)break;
    }
    // Some ATS job rows are buttons/divs rather than links. Keep their titles distinct.
    if(links.length<5){for(const h of document.querySelectorAll('h1,h2,h3,[class*="job-title"],[class*="position-title"]')){const label=visibleText(h,120);if(!titlePattern.test(label)||ignored.test(label)||links.some(x=>x.text===label))continue;const card=h.closest('article,li,[class*="job-item"],[class*="position-item"],[role="listitem"]')||h.parentElement;links.push({id:'a'+links.length,url:C.safeUrl(location.href),text:label,context:visibleText(card,1600)});if(links.length>=160)break;}}
    const scope=document.querySelector('main,[role="main"],[class*="job-detail"],[class*="jobDetail"],[class*="position-detail"],[class*="recruit"]')||document.body;
    if(!manual && !structured.length && !links.length && !jobPattern.test(location.pathname+' '+document.title))return null;
    const text=visibleText(scope,18000),cycle=(document.title+' '+text.slice(0,1800)).match(/20\d{2}\s*年?\s*(?:届|校园招聘|校招|春招|秋招|实习招聘)/)?.[0]||'';
    return {url:C.safeUrl(location.href),title:C.redact(C.text(document.title,250)),company,company_evidence,company_scope,cycle,headings:headings.slice(0,45),links,structured:structured.slice(0,120),text,manual:!!manual};
  }
  async function scan(manual=false) {
    if(running){pending ||= manual;return;}
    running=true;
    try{
      const status=await send({type:'SCANNER_READY'});if(!status?.ok||status.skip||(!status.enabled&&!manual))return;
      const snapshot=build(manual);if(!snapshot)return;
      const fingerprint=await C.hash(JSON.stringify([location.href,snapshot.title,snapshot.company_evidence,snapshot.company_scope,snapshot.text,snapshot.links,snapshot.structured]));
      if(!manual&&(fingerprint===lastFingerprint||Date.now()-lastRun<5000))return;
      lastFingerprint=fingerprint;lastRun=Date.now();
      await send({type:'SNAPSHOT',snapshot});
    }catch{/* Extension reload/closed tabs should not interfere with the hiring website. */}
    finally{running=false;if(pending){pending=false;setTimeout(()=>scan(true),200);}}
  }
  function schedule(){clearTimeout(timer);timer=setTimeout(()=>scan(false),1800);}
  function showHint(count){
    if(hint)return;
    const host=document.createElement('div');host.dataset.sugarTracker='true';host.style.cssText='position:fixed;right:20px;bottom:20px;z-index:2147483000';
    const shadow=host.attachShadow({mode:'closed'}),style=document.createElement('style');style.textContent='button{font:12px -apple-system,BlinkMacSystemFont,"Microsoft YaHei",sans-serif;cursor:pointer;border:0}.wrap{display:flex;align-items:center;border:1px solid #d6e8df;box-shadow:0 4px 18px #17212b15;background:white;border-radius:10px;padding:4px}.open{background:white;color:#256c51;padding:10px 12px;border-radius:7px}.close{background:white;color:#89958f;padding:8px;border-radius:6px}.open:hover{background:#eaf5ef}';
    const wrap=document.createElement('div');wrap.className='wrap';const open=document.createElement('button');open.className='open';open.textContent=`Sugar · 已整理 ${count} 个岗位`;open.addEventListener('click',()=>send({type:'OPEN_PANEL'}).catch(()=>{}));
    const close=document.createElement('button');close.className='close';close.textContent='×';close.setAttribute('aria-label','关闭 Sugar 提示');close.addEventListener('click',()=>{host.remove();hint=null;});wrap.append(open,close);shadow.append(style,wrap);document.documentElement.append(host);hint=host;
  }
  function onMessage(message,_sender,reply){if(message?.type==='SUGAR_GET_SNAPSHOT'){reply({snapshot:build(true)});return;}if(message?.type==='SUGAR_SCAN_NOW'){scan(true);reply({accepted:true});return;}if(message?.type==='SUGAR_JOBS_FOUND')showHint(message.count);}
  chrome.runtime.onMessage.addListener(onMessage);
  const observer=new MutationObserver(records=>{if(records.some(r=>!r.target.closest?.('[data-sugar-tracker]')))schedule();});observer.observe(document.documentElement,{childList:true,subtree:true,characterData:true});
  window.addEventListener('popstate',schedule);window.addEventListener('hashchange',schedule);window.addEventListener('online',schedule);
  // URL changes via pushState do not always mutate a visible node immediately.
  let previousURL=location.href;const interval=setInterval(()=>{if(previousURL!==location.href){previousURL=location.href;lastFingerprint='';schedule();}},2500);
  globalThis.__sugarJobScanner={version,refresh:schedule,dispose(){clearTimeout(timer);clearInterval(interval);observer.disconnect();chrome.runtime.onMessage.removeListener(onMessage);window.removeEventListener('popstate',schedule);window.removeEventListener('hashchange',schedule);window.removeEventListener('online',schedule);hint?.remove();}};schedule();
})();
