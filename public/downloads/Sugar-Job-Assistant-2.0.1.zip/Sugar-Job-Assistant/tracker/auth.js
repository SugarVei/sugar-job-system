(function (root) {
  'use strict';
  const cfg = root.SugarTrackerConfig, vault = root.SugarTrackerPrivate;
  let refreshPromise, generation = 0;
  async function request(path, init = {}) {
    const response = await fetch(cfg.supabaseUrl + '/auth/v1/' + path, { ...init, signal: AbortSignal.timeout(20000), headers: { apikey: cfg.publishableKey, 'Content-Type': 'application/json', ...init.headers } });
    const data = response.status === 204 ? null : await response.json().catch(() => null);
    if (!response.ok) {
      const code = data?.error_code || data?.code || '';
      let message = data?.msg || data?.message || data?.error_description || '登录服务暂不可用';
      if (/invalid_credentials|Invalid login credentials/i.test(code + message)) message = '邮箱或密码不正确，请使用 Sugar 网站的账号。';
      if (/email_not_confirmed/i.test(code)) message = '请先在邮箱中确认注册，再登录。';
      if (response.status === 429) message = '登录操作过于频繁，请稍后再试。';
      const e = new Error(message); e.status = response.status; e.code = code; throw e;
    }
    return data;
  }
  function pack(data) { if (!data?.access_token || !data?.refresh_token || !data?.user?.id || data.user.is_anonymous) throw new Error('请登录已有的 Sugar 注册账号。'); return { access_token: data.access_token, refresh_token: data.refresh_token, expires_at: data.expires_at || Math.floor(Date.now()/1000) + (data.expires_in || 3600), user: { id: data.user.id, email: data.user.email || '', phone: data.user.phone || '' } }; }
  async function login(email, password) {
    const current = ++generation;
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email || '') || !password) throw new Error('请输入网站账号邮箱和密码。');
    const data = await request('token?grant_type=password', { method: 'POST', body: JSON.stringify({ email: email.trim(), password }) });
    if (current !== generation) throw new Error('登录操作已取消，请重试。');
    const session = pack(data); await vault.set('session', session); return session;
  }
  async function refresh(force = false) {
    if (refreshPromise) return refreshPromise;
    refreshPromise = (async () => {
      const saved = await vault.get('session');
      if (!saved?.user?.id) throw Object.assign(new Error('请先登录 Sugar 网站账号。'), { code: 'AUTH_REQUIRED' });
      if (!force && saved.expires_at > Date.now()/1000 + 60) return saved;
      const current = generation;
      try {
        const data = await request('token?grant_type=refresh_token', { method: 'POST', body: JSON.stringify({ refresh_token: saved.refresh_token }) });
        if (generation !== current) throw Object.assign(new Error('账号已切换，请重新操作。'), { code: 'AUTH_REQUIRED' });
        const next = pack(data); if (next.user.id !== saved.user.id) throw new Error('登录身份不一致，请重新登录。'); await vault.set('session', next); return next;
      } catch (error) { if ([400,401,403].includes(error.status) && generation === current) { await vault.remove('session'); error.code = 'AUTH_REQUIRED'; error.message = '登录已失效，请重新登录同一个 Sugar 账号。'; } throw error; }
    })().finally(() => { refreshPromise = null; });
    return refreshPromise;
  }
  async function verified() { const s = await refresh(); try { const u = await request('user', { headers: { Authorization: 'Bearer ' + s.access_token } }); if (u.id !== s.user.id || u.is_anonymous) throw new Error('登录身份不一致。'); return s; } catch (error) { if (error.status === 401) { await vault.remove('session'); error.code = 'AUTH_REQUIRED'; error.message = '登录已失效，请重新登录。'; } throw error; } }
  async function logout() { const saved = await vault.get('session'); generation++; await vault.remove('session'); if (saved?.access_token) request('logout?scope=local', { method: 'POST', headers: { Authorization: 'Bearer ' + saved.access_token } }).catch(() => {}); }
  async function user() { const s = await vault.get('session'); return s?.user || null; }
  root.SugarTrackerAuth = Object.freeze({ login, refresh, verified, logout, user });
})(globalThis);
