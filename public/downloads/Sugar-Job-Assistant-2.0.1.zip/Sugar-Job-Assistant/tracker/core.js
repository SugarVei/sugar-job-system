(function (root) {
  'use strict';
  const text = (v, max = 500) => String(v ?? '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);
  const normalize = v => text(v, 3000).toLowerCase().replace(/[\s\p{P}\p{S}]+/gu, '');
  const redact = v => String(v || '').replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, '[邮箱已移除]').replace(/(?<!\d)1[3-9]\d{9}(?!\d)/g, '[手机号已移除]').replace(/(?<!\d)\d{17}[\dXx](?!\d)/g, '[证件号已移除]').replace(/(?:Bearer\s+|(?:api[_-]?key|access[_-]?token|refresh[_-]?token)\s*[:=]\s*)[^\s,;"}]+/gi, '[凭证已移除]');
  function safeUrl(value, base) { try { const u = new URL(value, base); if (!['https:', 'http:'].includes(u.protocol) || u.username || u.password) return ''; for (const k of [...u.searchParams.keys()]) if (/token|auth|session|password|email|phone|mobile|code_verifier|signature|^utm_|^(?:spm|from|source|ref|referrer|gclid|fbclid)$/i.test(k)) u.searchParams.delete(k); u.searchParams.sort(); u.hash = ''; return u.href.slice(0, 2200); } catch { return ''; } }
  function identity(j) { return [safeUrl(j.url), normalize(j.company), normalize(j.title), normalize(j.city), normalize(j.code), normalize(j.cycle)].join('|'); }
  async function hash(value) { const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(String(value))); return [...new Uint8Array(bytes)].map(n => n.toString(16).padStart(2, '0')).join(''); }
  async function uuid(value) { const h = (await hash(value)).slice(0, 32).split(''); h[12] = '5'; h[16] = '8'; const s = h.join(''); return `${s.slice(0,8)}-${s.slice(8,12)}-${s.slice(12,16)}-${s.slice(16,20)}-${s.slice(20)}`; }
  function today() { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; }
  function validDate(v) { if (!/^\d{4}-\d{2}-\d{2}$/.test(v || '')) return false; const d = new Date(v + 'T12:00:00Z'); return !Number.isNaN(d.getTime()) && d.toISOString().slice(0,10) === v && v <= today(); }
  const platformName = /^(?:logo\d*|首页|主页|官方|官网|全球|中国|人才|招聘|岗位|职位|详情|搜索|校园|校招|社招|应届生|实习生|招聘职位|个人中心|公司名称待补全|公司|集团|科技|电子|careers?|jobs?|home|talent|recruitment|beisen|moka|mokahr|北森|飞书|feishu|智联招聘|前程无忧|BOSS直聘|猎聘|拉勾|牛客|indeed|linkedin|powered by.*)$/i;
  function companyName(value) {
    let name = text(redact(value), 180).replace(/^(?:copyright\s*©?|©)\s*(?:20\d{2}(?:\s*[-–]\s*20\d{2})?)?\s*/i, '').replace(/(?:版权所有|all rights reserved)[\s\S]*$/i, '').trim();
    name = name.replace(/^(?:(?:20\d{2}\s*届?\s*)|全球|欢迎加入|加入我们[:：]?\s*)+/i, '').replace(/\s*(?:(?:全球|国内|海外|中国|年度|春季|秋季|春|秋)?(?:校园招聘|社会招聘|人才招聘|招聘官网|招聘网站|校招官网|招聘平台|校园|校招|社招|招聘|求职)|careers?|recruitment|official\s*(?:website|site)|官网|官方网站|网站|首页|主页|logo)\s*$/ig, '').trim();
    name = name.replace(/^[\s|｜·:：-]+|[\s|｜·:：-]+$/g, '');
    if (name.length < 2 || name.length > 100 || platformName.test(name) || /[邮箱手机号凭证]+已移除|https?:|登录|退出|个人中心|工程师|专员|岗位职责|职位描述|请输入|寻找你的|点击|copyright|powered\s*by|(?:招聘|校园|求职|岗位|职位|jobs?|careers?)$/i.test(name)) return '';
    return name;
  }
  function multipleEmployers(snapshot = {}) {
    const names = new Set((snapshot.structured || []).map(j => normalize(j.company || j.company_name)).filter(Boolean));
    return names.size > 1 || snapshot.company_scope === 'multiple';
  }
  function companyCandidates(snapshot = {}) {
    if (multipleEmployers(snapshot)) return [];
    const out = [];
    const add = (value, score, source) => { const name = companyName(value); if (name && !out.some(x => normalize(x.name) === normalize(name))) out.push({name, score, source}); };
    for (const j of snapshot.structured || []) add(j.company || j.company_name, 100, '岗位结构化公司');
    add(snapshot.company, 98, '页面公司');
    for (const item of snapshot.company_evidence || []) {
      if (!item || typeof item !== 'object') continue;
      if (['organization','logo','site_name','company_label'].includes(item.kind)) add(item.text, ({organization:96,logo:94,site_name:90,company_label:95})[item.kind], item.kind);
      if(item.kind==='header'){
        const match=text(item.text,700).match(/(?:^|\s)([\p{L}\p{N}（）()·&.-]{2,60}(?:有限公司|股份公司|集团|科技|电子|银行|大学))(?=\s|招聘|校招|$)/u);
        if(match)add(match[1],86,'页眉公司');
      }
    }
    for (const part of text(snapshot.title, 250).split(/[|｜·—–]/)) add(part, 80, '页面标题');
    // A verified first-party domain also works when the logo has no accessible text.
    try { if (/(^|\.)boe\.com(?:\.cn)?$/i.test(new URL(snapshot.url).hostname)) add('京东方', 85, '京东方官方域名'); } catch {}
    return out.sort((a,b) => b.score-a.score);
  }
  function inferCompany(snapshot = {}) { return companyCandidates(snapshot)[0]?.name || ''; }
  function companySource(snapshot = {}) {
    return [snapshot.title, snapshot.company, snapshot.text, ...(snapshot.headings || []), ...(snapshot.company_evidence || []).map(x=>x.text), ...(snapshot.links || []).map(x=>x.text+' '+x.context), ...(snapshot.structured || []).map(x=>x.company)].filter(Boolean).join(' ');
  }
  function groundedCompany(value, snapshot = {}) {
    const name = companyName(value); if (!name) return '';
    const source = normalize(companySource(snapshot));
    if (source.includes(normalize(name))) return name;
    return companyCandidates(snapshot).find(x=>normalize(x.name)===normalize(name))?.name || '';
  }
  function normalizeJob(raw, snapshot = {}) {
    const title = text(raw.title || raw.position_name, 130);
    if (!title || /^(?:职位|岗位|工作|招聘|搜索|职位列表|岗位列表|首页|详情|jobs?|careers?|positions?)$/i.test(title)) return null;
    const job = { title, company: text(raw.company || raw.company_name || snapshot.company, 180), city: text(raw.city, 160), code: text(raw.code || raw.posting_id, 130), cycle: text(raw.cycle || raw.recruitment_cycle || snapshot.cycle, 100), salary: text(raw.salary || raw.salary_range, 120), jd: redact(text(raw.jd || raw.jd_text, 9000)), url: safeUrl(raw.url || raw.job_url || snapshot.url, snapshot.url), source_url: safeUrl(raw.source_url || snapshot.url || raw.url), channel: text(raw.channel || '官网', 40), resume_id: null, evidence: text(raw.evidence, 500), extraction: raw.extraction || '规则提取', missing_detail: !text(raw.jd || raw.jd_text) };
    if (!job.url) return null;
    job.id = identity(job); return job;
  }
  function dedupe(jobs) { const seen = new Set(); return jobs.filter(j => { if (!j || seen.has(j.id)) return false; seen.add(j.id); return true; }); }
  function plainHTML(html) { return text(String(html || '').replace(/<(script|style|form|nav|footer)\b[^>]*>[\s\S]*?<\/\1>/gi, ' ').replace(/<\/(?:p|div|li|h[1-6])>/gi, '\n').replace(/&nbsp;/g,' ').replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>'), 18000); }
  function jsonJobs(value) { const out = []; const walk = (v, depth = 0) => { if (!v || depth > 12 || out.length >= 150) return; if (Array.isArray(v)) { v.forEach(x => walk(x, depth+1)); return; } if (typeof v !== 'object') return; if ([v['@type']].flat().some(t => t === 'JobPosting')) out.push(v); for (const k of ['@graph','mainEntity','itemListElement','item','hasPart']) if (v[k]) walk(v[k], depth+1); }; walk(value); return out; }
  function fromJSONLD(v, base) { const locations = [v.jobLocation].flat().filter(Boolean).map(x => x.address || x).map(x => text(x.addressLocality || x.addressRegion || x.name)).filter(Boolean); const salary = v.baseSalary?.value; return normalizeJob({ title: v.title, company: v.hiringOrganization?.name, city: locations.join(' / ') || (v.jobLocationType === 'TELECOMMUTE' ? '远程' : ''), code: v.identifier?.value || (typeof v.identifier === 'string' ? v.identifier : ''), url: v.url || base, jd: plainHTML(v.description), salary: salary && typeof salary === 'object' ? [salary.minValue, salary.maxValue].filter(Boolean).join('–') : salary, extraction: '结构化岗位', evidence: '页面 JobPosting 结构化数据' }, { url: base }); }
  function errorMessage(error) { const s = String(error?.message || error || '操作失败'); if (/Failed to fetch|network|ERR_|fetch failed|timeout|aborted/i.test(s)) return '网络暂不可用，请检查连接后重试。'; return redact(s).slice(0, 250); }
  const api = { text, normalize, redact, safeUrl, identity, hash, uuid, today, validDate, companyName, multipleEmployers, companyCandidates, inferCompany, companySource, groundedCompany, normalizeJob, dedupe, plainHTML, jsonJobs, fromJSONLD, errorMessage };
  root.SugarTrackerCore = Object.freeze(api);
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(globalThis);
